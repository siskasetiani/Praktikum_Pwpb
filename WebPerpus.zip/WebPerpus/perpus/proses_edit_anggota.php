<?php 

 	include "koneksi.php";  // call connection php mysql

 		// sql query INSERT INTO VALUES
 	$query = "UPDATE anggota SET
 				nm_anggota= '$_POST[nm_anggota]',
 				alamat= '$_POST[alamat]',
 				ttl_anggota= '$_POST[ttl_anggota]',
 				status_anggota= '$_POST[status_anggota]'

 				WHERE id_anggota= '$_POST[id_anggota]'
 				";

 	 	// run query
 	 $update = mysqli_query($koneksi, $query);

 	 if ($update) {
        echo '<script> alert("User added successfully");</script>';
    } else {
        echo '<script>alert("User add failed");</script>';
    }
 ?>