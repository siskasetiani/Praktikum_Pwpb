<?php 

$servername = "localhost";
$user		= "root";
$password	= "";
$db			= "perpus";

$koneksi = mysqli_connect ($servername,$user,$password) or die ("cannot connect");

mysqli_select_db($koneksi, $db) or die ("cannot select db");
?>
